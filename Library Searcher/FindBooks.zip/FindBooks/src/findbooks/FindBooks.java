//By Areebah Fatima

package findbooks;


// Imports
import javafx.scene.control.Button;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import java.sql.*;
import static javafx.application.Application.launch;
import javafx.geometry.Pos;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;


public class FindBooks extends Application {
  
  // PreparedStatement for executing queries
  private PreparedStatement preparedStatement;

  // Connection class object
  Connection connection;
  
  // Holds list of author names
  private final ObservableList<String> names = FXCollections.observableArrayList();
  private TextArea txtArea = new TextArea();

  
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    
    // Label 
    Label listHeader = new Label("Please Select an Author from the Following List");
 
    // Initialize database connection and create a Statement object
    initializeDB();

    // Buttons for search and exit
    Button btnShowBooks = new Button("Find Books");
    Button btnExit = new Button("Exit");
 
    // Call function to read a list of authors from the BookDB and store them
    getAuthors();
      
    // Create ListView to display author names
    ListView<String> listView = new ListView<String>(names);
    listView.setMaxSize(200, 160);
  
   
    txtArea.setPrefHeight(100);
    txtArea.setPrefWidth(100);

    // For Horizontal Column layout (will have our buttons)
    HBox hBox = new HBox(10);
    hBox.getChildren().addAll(btnShowBooks, btnExit);
    hBox.setAlignment(Pos.CENTER);
    
    // For Veritcal Column layout (will have header, listview, hBox, and textArea)
    VBox vBox = new VBox(10);
    vBox.getChildren().addAll(listHeader, listView, hBox, txtArea);
    vBox.setAlignment(Pos.CENTER);
    
    // The following will occur when the search button is clicked
    btnShowBooks.setOnAction((ActionEvent e) -> {
        // Store user selection and pass it to the findBooks function
        String choice = listView.getSelectionModel().getSelectedItem();
        findBooks(choice);
    });
    
    // The following will occur when the exit button is clicked
    btnExit.setOnAction((ActionEvent e) -> {
        System.out.println("Goodbye!");
        primaryStage.close();
    });
    
    // Create a scene and place it in the stage
    Scene scene = new Scene(vBox, 550, 400);
    primaryStage.setTitle("Find Books"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage   
    
  }

  private void initializeDB() {
    
    // Try-Catch Block
    try {

      // Establish a connection (Changes based on machine)
      connection = DriverManager.getConnection("jdbc:derby://localhost:1527/BookDB", "areebah", "fatima");
      
      // Notify User in output box
      System.out.println("Database connected");
     
      // Our queryString to recover all author names from our database
      String queryString = "select author from Author" ;
       
      // Create a statement
      preparedStatement = connection.prepareStatement(queryString);

    }
    
    catch (Exception ex) {
      ex.printStackTrace();
    }
    
  }

  
  private void getAuthors() {
    
    String name;
    
    // Try-Catch Block
    try {
      
      
      ResultSet rset = preparedStatement.executeQuery();
      
      // If true it means our search returned results
      if(rset.next()){
        
        do{

            // Retrieve names and add them to the listView
            name = rset.getString(1);
            names.add(name);

        }while(rset.next());    // While there is still items to look through
            
      }
      
      else{
          
          // If true it means we weren't able to recover any names (notify user)
          names.add("No Authors Found");
          System.out.println("No Authors Found");
      }
    } 
  
    catch (SQLException ex) {
      ex.printStackTrace();
    }
    
  }
  
  private void findBooks(String author) {

    // Try-Catch Block
    try {
        
    
         // Our queryString to recover the books for a chosen author
         String queryString = "select Book.title from Author, Book, WrittenBy " +
          "where Author.author = ? and " +
          "Author.id = WrittenBy.id and " +
          "Book.isbn = WrittenBy.isbn";
        
        
        preparedStatement = connection.prepareStatement(queryString);
        
        // Set our first ? set it to the users listView choice
        preparedStatement.setString(1, author);
        System.out.println("You've Selected: " + author);
  
        ResultSet rset = preparedStatement.executeQuery();
        
        // TextArea
        txtArea.setText("");
        System.out.println("Books by selected author: ");
        
        // If true it means our search returned results
        if(rset.next()){
        
            do{
                // Retrieve book names and add them to the TextArea
                String bookname = rset.getString(1);
                txtArea.appendText(bookname + " \n");
                System.out.println(bookname + " ");

            }while(rset.next()) ;   // While there is still items to look through
            
        }
        else{
            
             // If true it means we weren't able to recover any books (notify user)
             txtArea.appendText("No books found");
             System.out.println("No books found");
            
        }
            
    }
    catch (SQLException ex) {
      ex.printStackTrace();
    }
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  
  public static void main(String[] args) {
    launch(args);
  }
}

